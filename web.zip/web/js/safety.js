

function FillSafetyList()
{
    $$.getJSON('safetylist.json',function(json){
      myApp.template7Data.safetylist=json;
      //array to store the safetylist
      var safeties=[];
      for(var key in json)
      {
        if(json.hasOwnProperty(key))
        {
          var item=json[key];

          safeties.push({
            name: item.Name,
            id:item.id
          });
        }
      }

    for(var i=0; i<safeties.length;i++){
      var media=document.getElementById('safeties[i].id');
      var img=document.createElement('img');
      img.src="img/icon/warning.png";
      media.appendChild(img);
    }
  }
}
FillSafetyList();
