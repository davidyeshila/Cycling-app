// Lets register template7 helper so we can pass json string in links
Template7.registerHelper('json_stringify',function(context){
  return json.stringify(context);
});

// Init App
var myApp = new Framework7({
    modalTitle: 'Framework7',
    // Enable Material theme
    material: true,
    precompileTemplates:true,
    template7Pages:true
});

// Expose Internal DOM library
var $$ = Dom7;

// function get components
function getComponents(){
  $$.getJSON('components.json',function(json){
    myApp.template7Data.componentlist= json;

  })
}
    var safeties=[];

function setSafetyList(){
  $$.getJSON('safetylist.json',function(json){
    myApp.template7Data.safetylist=json;
    //array to store the safetylist
    var status=["good","warning","danger"];

      // checking if the staus already exist
    if(localStorage.getItem(status[0])===null)
    {
      localStorage.setItem(status[0],"img/icon/good.png");
    }
    if(localStorage.getItem(status[1])===null){
      localStorage.setItem(status[1],"img/icon/warning.png");
    }
    if(localStorage.getItem(status[2])===null){
      localStorage.setItem(status[2],"img/icon/danger.png");
    }

    // extracting the names from safetylist and putting it in the array
    for(var key in json)
    {
      if(json.hasOwnProperty(key))
      {
        var item=json[key];

        safeties.push({
          name: item.Name,
          id:item.id
        });
      }
    }
    // loop to check if the safetylist already exist, if it doesn't then sets the safetylist name
      for(var i=0; i<safeties.length;i++){
      if(localStorage.getItem(safeties[i].name)===null)
      {
        localStorage.setItem(safeties[i].name,"img/icon/good.png");
      }
      }
  })
  //
}

// Read the data from localStorage and display the status
$$(document).on('pageInit', '.page[data-page="safetylist"]', function (e) {
  for(var i=0; i<safeties.length;i++){
    var media=document.getElementById(safeties[i].name);
    var img=document.createElement('img');
    img.src=localStorage.getItem(safeties[i].name);
    media.appendChild(img);
  }
})

// calling functions
getComponents();
setSafetyList();

// Add main view
var mainView = myApp.addView('.view-main', {
});
/* ===== Action sheet, we use it on few pages ===== */
myApp.onPageInit('safetylist', function (page) {

    $$('.demo-actions').on('click', function (e) {
      //getting the elements id to set the status
      var x=this.id;

      var actionSheetButtons = [
          // First buttons group
          [
              // Group Label
              {
                  text: 'Choose a status',
                  label: true
              },
              // First button
              {
                  text: 'Good condition',
                  color: 'green',
                  onClick: function () {
                  localStorage.removeItem(safeties[x].name);
                  localStorage.setItem(safeties[x].name,"img/icon/good.png");
                  alert('Status updated.');
                  window.location.href="index.html";
                  }
              },
              // Second button
              {
                  text: 'Needs Servicing',
                  color: 'orange',
                  onClick: function () {
                    localStorage.removeItem(safeties[x].name);
                    localStorage.setItem(safeties[x].name,"img/icon/warning.png");
                    alert('Status updated.');
                    window.location.href="index.html";
                  }
              },
              // Another red button
              {
                  text: 'Needs to serviced/replaced immediately ',
                  color: 'red',
                  onClick: function () {
                    localStorage.removeItem(safeties[x].name);
                    localStorage.setItem(safeties[x].name,"img/icon/danger.png");
                    alert('Status updated.');
                    window.location.href="index.html";
                  }
              },
          ],
          // Second group
          [
              {
                  text: 'Cancel'
              }
          ]
      ];
        myApp.actions(actionSheetButtons);
    });
    $$('.demo-actions-popover').on('click', function (e) {
        // We need to pass additional target parameter (this) for popover
        myApp.actions(this, actionSheetButtons);
    });

});
